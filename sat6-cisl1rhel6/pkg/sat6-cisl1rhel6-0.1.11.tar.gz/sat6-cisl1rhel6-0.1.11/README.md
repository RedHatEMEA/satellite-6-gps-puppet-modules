## Overview

This is a Puppet module to implement CIS Level 1 for RHEL6.

It's been tested with RHEL6.6 using Red Hat Satellite 6.0

## Installation

The puppet module has been built, load the module file in the pkg sub directory into Satellite 6.

As it's the initial version of the module there are not many parameters other than the CIS section number booleans to run a section or not, some areas are so specific puppet files have been use that can be customise per site and the module rebuild.

## License

GPLv2, pull requests welcome

